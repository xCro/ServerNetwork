package ServerNetwork.MinigameCore.Spleef.utils;

public enum GameState {
  WAITING,INGAME,CLEANUP
}
